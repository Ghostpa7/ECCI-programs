import os
import sqlite3
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash

base_dir = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__, 
            template_folder=os.path.join(base_dir, 'templates'),
            static_folder=os.path.join(base_dir, 'static'))

app.secret_key = 'clave_secreta_ecci_dinero_colchon_2026'
DATABASE = os.path.join(base_dir, 'dinero_colchon.db')

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                description TEXT NOT NULL,
                amount REAL NOT NULL,
                type TEXT NOT NULL,
                category TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS savings_goals (
                user_id INTEGER PRIMARY KEY,
                goal REAL NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        conn.commit()

init_db()

@app.route('/')
def home():
    if 'user_id' not in session:
        return redirect(url_for('login_page'))
    return render_template('index.html', username=session.get('username'))

@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.json or {}
    username = data.get('username')
    password = data.get('password')

    with get_db() as conn:
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            return jsonify({'success': True})
    return jsonify({'success': False, 'message': 'Usuario o contraseña incorrectos'}), 401

@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.json or {}
    username = data.get('username')
    password = data.get('password')

    if not username or not password:
        return jsonify({'success': False, 'message': 'Campos incompletos'}), 400

    hashed_pw = generate_password_hash(password)
    try:
        with get_db() as conn:
            conn.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_pw))
            conn.commit()
        return jsonify({'success': True})
    except sqlite3.IntegrityError:
        return jsonify({'success': False, 'message': 'El usuario ya existe'}), 400

@app.route('/api/data', methods=['GET'])
def get_data():
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 401

    user_id = session['user_id']
    with get_db() as conn:
        txs = conn.execute('SELECT * FROM transactions WHERE user_id = ? ORDER BY id DESC', (user_id,)).fetchall()
        goal_row = conn.execute('SELECT goal FROM savings_goals WHERE user_id = ?', (user_id,)).fetchone()

    transactions = [dict(tx) for tx in txs]
    savings_goal = goal_row['goal'] if goal_row else 5000000.0

    return jsonify({
        'transactions': transactions,
        'savingsGoal': savings_goal
    })

@app.route('/api/transactions', methods=['POST'])
def add_transaction():
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 401

    data = request.json or {}
    user_id = session['user_id']
    desc = data.get('description')
    amount = float(data.get('amount', 0))
    tx_type = data.get('type')
    category = data.get('category')

    with get_db() as conn:
        conn.execute('''
            INSERT INTO transactions (user_id, description, amount, type, category)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, desc, amount, tx_type, category))
        conn.commit()

    return jsonify({'success': True})

@app.route('/api/transactions/<int:tx_id>', methods=['DELETE'])
def delete_transaction(tx_id):
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 401

    with get_db() as conn:
        conn.execute('DELETE FROM transactions WHERE id = ? AND user_id = ?', (tx_id, session['user_id']))
        conn.commit()

    return jsonify({'success': True})

@app.route('/api/transactions/clear', methods=['DELETE'])
def clear_transactions():
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 401

    with get_db() as conn:
        conn.execute('DELETE FROM transactions WHERE user_id = ?', (session['user_id'],))
        conn.commit()

    return jsonify({'success': True})

@app.route('/api/goal', methods=['POST'])
def update_goal():
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'}), 401

    data = request.json or {}
    goal = float(data.get('goal', 5000000))
    user_id = session['user_id']

    with get_db() as conn:
        conn.execute('''
            INSERT INTO savings_goals (user_id, goal) VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET goal = excluded.goal
        ''', (user_id, goal))
        conn.commit()

    return jsonify({'success': True})

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})

if __name__ == '__main__':
    app.run(debug=True, port=8000)
