let chartInstance = null;
let currentGoal = 5000000;
let rawTransactions = [];

const formatCOP = (val) => {
    return new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        maximumFractionDigits: 0
    }).format(val);
};

document.addEventListener('DOMContentLoaded', () => {
    initChart();
    loadData();
});

function toggleTheme() {
    const html = document.documentElement;
    const currentTheme = html.getAttribute('data-theme') || 'dark';
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', newTheme);
    showToast(`Tema cambiado a modo ${newTheme}`, 'success');
}

function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
    toast.innerHTML = `<i class="fa-solid ${icon}"></i> ${message}`;
    
    container.appendChild(toast);
    setTimeout(() => { toast.remove(); }, 3000);
}

function openTransactionModal() {
    document.getElementById('txModal').style.display = 'flex';
}

function closeTransactionModal() {
    document.getElementById('txModal').style.display = 'none';
}

async function loadData() {
    try {
        const res = await fetch('/api/data');
        if (res.status === 401) {
            window.location.href = '/login';
            return;
        }
        const data = await res.json();
        rawTransactions = data.transactions || [];
        currentGoal = data.savingsGoal || 5000000;
        
        const goalInput = document.getElementById('goalInput');
        if (goalInput) goalInput.value = currentGoal;
        
        applyFilters();
    } catch (err) {
        console.error("Error al cargar datos:", err);
    }
}

function applyFilters() {
    const dateRange = document.getElementById('dateFilter') ? document.getElementById('dateFilter').value : 'all';
    const typeFilter = document.getElementById('typeFilter') ? document.getElementById('typeFilter').value : 'all';
    
    const now = new Date();
    
    let filtered = rawTransactions.filter(tx => {
        const txDate = tx.created_at ? new Date(tx.created_at) : new Date();
        let passDate = true;
        
        if (dateRange === 'month') {
            passDate = txDate.getMonth() === now.getMonth() && txDate.getFullYear() === now.getFullYear();
        } else if (dateRange === '3months') {
            const threeMonthsAgo = new Date();
            threeMonthsAgo.setMonth(now.getMonth() - 3);
            passDate = txDate >= threeMonthsAgo;
        } else if (dateRange === 'year') {
            passDate = txDate.getFullYear() === now.getFullYear();
        }

        let passType = (typeFilter === 'all') || (tx.type === typeFilter);
        return passDate && passType;
    });

    renderApp(filtered);
}

function renderApp(transactions) {
    const income = transactions.filter(t => t.type === 'ingreso').reduce((acc, t) => acc + t.amount, 0);
    const expense = transactions.filter(t => t.type === 'egreso').reduce((acc, t) => acc + t.amount, 0);
    const balance = income - expense;

    document.getElementById('totalBalance').innerText = formatCOP(balance);
    document.getElementById('totalIncome').innerText = formatCOP(income);
    document.getElementById('totalExpense').innerText = formatCOP(expense);

    const progress = Math.min(Math.max((balance / currentGoal) * 100, 0), 100).toFixed(1);
    document.getElementById('savingsProgress').innerText = `${progress}%`;
    
    const progressBar = document.getElementById('progressBar');
    if (progressBar) progressBar.style.width = `${progress}%`;

    const tbody = document.getElementById('transactionList');
    tbody.innerHTML = '';

    if (transactions.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color: var(--text-muted); padding: 20px;">No hay transacciones registradas. ¡Agrega una nueva!</td></tr>`;
    } else {
        transactions.forEach(tx => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${tx.created_at ? tx.created_at.split(' ')[0] : 'Hoy'}</td>
                <td><strong>${tx.description}</strong></td>
                <td><span style="background: rgba(255,255,255,0.08); padding: 4px 8px; border-radius: 6px; font-size: 0.8rem;">${tx.category}</span></td>
                <td class="${tx.type === 'ingreso' ? 'type-ingreso' : 'type-egreso'}">${tx.type.toUpperCase()}</td>
                <td><strong>${formatCOP(tx.amount)}</strong></td>
                <td>
                    <button class="btn-clear" onclick="deleteTransaction(${tx.id})">
                        <i class="fa-solid fa-trash-can"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }

    updateChart(transactions);
}

async function addTransaction(e) {
    e.preventDefault();
    const description = document.getElementById('description').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const type = document.getElementById('type').value;
    const category = document.getElementById('category').value;

    if (!description || isNaN(amount) || amount <= 0) {
        showToast('Por favor ingresa una descripción y monto válidos', 'error');
        return;
    }

    const res = await fetch('/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description, amount, type, category })
    });

    if (res.ok) {
        closeTransactionModal();
        document.getElementById('description').value = '';
        document.getElementById('amount').value = '';
        showToast('¡Transacción agregada correctamente!', 'success');
        loadData();
    } else {
        showToast('Error al guardar la transacción', 'error');
    }
}

async function deleteTransaction(id) {
    if (confirm('¿Seguro que deseas eliminar este movimiento?')) {
        const res = await fetch(`/api/transactions/${id}`, { method: 'DELETE' });
        if (res.ok) {
            showToast('Transacción eliminada', 'error');
            loadData();
        }
    }
}

async function clearAllTransactions() {
    if (confirm('¿Deseas vaciar todo tu historial de transacciones?')) {
        const res = await fetch('/api/transactions/clear', { method: 'DELETE' });
        if (res.ok) {
            showToast('Historial vaciado correctamente', 'error');
            loadData();
        }
    }
}

async function updateGoal() {
    const goalInput = document.getElementById('goalInput');
    const goal = parseFloat(goalInput.value);
    if (!isNaN(goal) && goal > 0) {
        const res = await fetch('/api/goal', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ goal })
        });
        if (res.ok) {
            showToast('¡Presupuesto / Meta guardada exitosamente!', 'success');
            loadData();
        }
    } else {
        showToast('Ingresa un monto válido para la meta', 'error');
    }
}

async function logout() {
    await fetch('/api/logout', { method: 'POST' });
    window.location.href = '/login';
}

function initChart() {
    const ctx = document.getElementById('expenseChart');
    if (!ctx) return;
    
    chartInstance = new Chart(ctx.getContext('2d'), {
        type: 'doughnut',
        data: { labels: [], datasets: [{ data: [], backgroundColor: ['#8b5cf6', '#06b6d4', '#f59e0b', '#ef4444', '#10b981'], borderWidth: 0 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: { color: '#94a3b8' } } } }
    });
}

function updateChart(transactions) {
    if (!chartInstance) return;
    const expenses = transactions.filter(t => t.type === 'egreso');
    const categories = {};
    expenses.forEach(e => { categories[e.category] = (categories[e.category] || 0) + e.amount; });

    chartInstance.data.labels = Object.keys(categories);
    chartInstance.data.datasets[0].data = Object.values(categories);
    chartInstance.update();
}
